package com.rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;

import org.json.JSONException;
import org.json.JSONObject;

public class CommonServices {
	 private static String readAll(Reader rd) throws IOException {
	        StringBuilder sb = new StringBuilder();
	        int cp;
	        while ((cp = rd.read()) != -1) {
	          sb.append((char) cp);
	        }
	        return sb.toString();
	      }
	    
	   public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
	        InputStream is = new URL(url).openStream();
	        try {
	          BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
	          String jsonText = readAll(rd);
	          JSONObject json = new JSONObject(jsonText);
	          return json;
	        } finally {
	          is.close();
	        }
	      }
	
	 public static String renderHtml() {
	    	String baseHtml="<!DOCTYPE html>" +
	    					 "<html>" +
	    					"<head>" + 
	    					"<meta charset=\"UTF-8\">"+
	    					"  <link href=\"main.css\" rel=\"stylesheet\">" + 
	    					"</head>" +
	    					"<header>" +
	    					"<nav   id=\"main-menu\" aria-labelledby=\"main-menu-title\">" + 
	    					"    					        <a href=\"index.html\" class=\"block\" >Home</a>" + 
	    					"    					        <a href=\"about.html\" class=\"block\" >About</a>" + 
	    					"    					        <a href=\"GeoLocation.html\" class=\"block\" >GeoLocation</a>" + 
	    					"    					 \r\n" + 
	    					"</nav>"+ 
	    					" </header>" +
	    					"<div class=\"sidebar\" style = \"margin: 0;\r\n" + 
	    					"  padding: 0;\r\n" + 
	    					"  width: 100px;\r\n" + 
	    					"  background-color: #f1f1f1;\r\n" + 
	    					"  position: fixed;\r\n" + 
	    					"  height: 100%;\r\n" + 
	    					"  overflow: auto;\">\r\n" + 
	    					"  <h2>W<br>E<br>A<br>T<br>H<br>E<br>R<br> <br>A<br>P<br>P<br>L<br>I<br>C<br>A<br>T<br>I<br>O<br>N<br></h2>\r\n" + 
	    					"</div>"+
	    					"<body  style=\"text-align: center;\">";
	    	return baseHtml;
	    			
	    	
	    }


}
