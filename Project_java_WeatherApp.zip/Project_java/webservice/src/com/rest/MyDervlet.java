package com.rest;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Servlet implementation class MyDervlet
 */
@WebServlet("/MyDervlet")
public class MyDervlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyDervlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		PrintWriter out = response.getWriter() ;
//		out.print("Service method called");
//	}
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter() ;
		String name = request.getParameter("fname");

		String url = "https://api.mapbox.com/geocoding/v5/mapbox.places/"+name+".json?access_token=pk.eyJ1IjoiYWZyaWRpMjMiLCJhIjoiY2tjd212aWJhMGN1dDJ5bXB0NHM4YjJzbCJ9.qmzWZTeOMbeJmwFmI48brw ";

		String resultname="";
		Double longitude=0.0;
		Double latitude=0.0;
		JSONObject json;
		
		try
		{
		
		try {
			json = CommonServices.readJsonFromUrl(url);
			Object cityFeature = json.get("features");
			
				String featureString=cityFeature.toString();
				if(featureString.length()<3)
				{
					out.print("<p class=\"redmsg\">\r\n" + 
							"Please enter a valid place name\r\n" + 
							"</p>");
					RequestDispatcher rd = null;
					rd= request.getRequestDispatcher("service.html");
					rd.include(request, response);
					return;
				}
				else
				{
				JSONArray arr = new  JSONArray(featureString);
				JSONObject obj1= arr.getJSONObject(0);
				Object cityname = obj1.get("place_name");
				resultname=cityname.toString();
				Object center = obj1.get("center");
				String centerString = center.toString();
				JSONArray centerarry = new  JSONArray(centerString);
				longitude = centerarry.getDouble(0);
				latitude = centerarry.getDouble(1);
				}
			
		
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			//PrintWriter out = response.getWriter() ;
			out.print("<p class=\"msg\">\r\n" + 
					"Please enter a valid place name\r\n" + 
					"</p>");
			RequestDispatcher rd = null;
			rd= request.getRequestDispatcher("service.html");
			rd.include(request, response);
			name=name+"error";
			e.printStackTrace();
			return;
		}
		
		}
		finally{ }
		int sz =resultname.length();
		if(sz>30)
		{
			//resultname=resultname.substring(0, 13)+" ... "+resultname.substring(sz-13, sz);
		}
		out.print(CommonServices.renderHtml());
		out.print("<h3> Your query place :  " + name + "</h3>");
		out.print("<h3> Best matched place :  " + resultname + "</h3>");
		out.print("<h3>The location parameter of "+resultname + "  are :</h3>");
		out.print("<table class=\"center\">");
		out.print("<tr><th>Latitude  : </th><th>"+ latitude+"</th></tr>");
		out.print("<tr><th>Longitude  : </th><th>"+ longitude+"</th></tr>");
		out.print("</table>");
		ServletContext context= getServletContext();
		context.setAttribute("long", longitude);
		context.setAttribute("lat", latitude);
		context.setAttribute("place", resultname);
		out.print("<br>");
		out.print(" <form action=\"Weather\">" + 
						 " <input type=\"submit\" value=\"Click To get weather details\">" + 
						 "<input type=\"hidden\" name=\"longitude\" value="+longitude+">" +
						 "<input type=\"hidden\" name=\"latitude\" value="+latitude+">" +
						 "<input type=\"hidden\" name=\"place\" value="+resultname+">" +
					" </form><br>");
		out.print(" <form action=\"MyDervlet\">" + 
				"<input type=\"text\" name=\"fname\" >" +
				" 	<input type=\"submit\" value=\"Change city\">" + 
				" </form>");
//		
//		RequestDispatcher rd = null;
//		rd= request.getRequestDispatcher("Weather");
//		rd.forward(request, response);
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String latitude = request.getParameter("latitude");
		String longitude = request.getParameter("longitude");
		String url="http://api.openweathermap.org/data/2.5/weather?lat="+latitude+"&lon="+longitude+"&appid=d85e1e13be2ede335baa58315adac3be";
		String res="";
		try
		{
		JSONObject json;
		try {
			json = CommonServices.readJsonFromUrl(url);
			//System.out.println(json.toString());
			//name=json.toString();
			Object mainObject = json.get("main");
			String x = mainObject.toString();
			JSONObject y = new JSONObject(x);
			res=mainObject.toString();
			PrintWriter out = response.getWriter() ;
			out.println(y.get("temp"));
			//out.print("Post method called by post....."+res );
			
			
//			String[] key1= JSONObject.getNames(obj1);
//			name=key1[1];
			
			//name = x.toString();
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		finally{ }
		PrintWriter out = response.getWriter() ;
		out.print("**Post**");
		out.print("Post method called by....."+res );
		
		
	}

}
