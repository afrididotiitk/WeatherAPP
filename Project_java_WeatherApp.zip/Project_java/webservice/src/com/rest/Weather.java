package com.rest;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Servlet implementation class Weather
 */
@WebServlet("/Weather")
public class Weather extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Weather() {
        super();
        // TODO Auto-generated constructor stub
    }
    

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out =response.getWriter();
		//ServletContext context= getServletContext();
//		double longitude=(double)context.getAttribute("long");
		String longitude=request.getParameter("longitude");
		String latitude=request.getParameter("latitude");
		String placeName=request.getParameter("place");
		
		String url="http://api.openweathermap.org/data/2.5/weather?lat="+latitude+"&lon="+longitude+"&appid=d85e1e13be2ede335baa58315adac3be";
		JSONObject json,main = null;
		Object mainObj;
		try
		{
					json = CommonServices.readJsonFromUrl(url);
					mainObj = json.get("main");
					String mainObjString = mainObj.toString();
					main = new JSONObject(mainObjString);
		}
		
		catch(IOException| JSONException e){
			out.print("Sorry failed to access this place weather Please try another place");
			RequestDispatcher rd = null;
			rd= request.getRequestDispatcher("GeoLocation.html");
			rd.include(request, response);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.print(CommonServices.renderHtml());
		out.print("<h2> Weather in " + placeName + "</h2>");
		out.print("<table class=\"center\">");
		try {
			out.println("<tr><th>Temperature  :  </th><th>" + main.get("temp")+"</th></tr>");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			out.println("<tr><th>Temperature   :  </th><th>not found</th></tr>");
			e.printStackTrace();
		}
		try {
			out.println("<tr><th>Feels_like   :  </th><th>" + main.get("feels_like")+"</th></tr>");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			out.println("<tr><th>Feels_like   :  </th><th>not found</th></tr>");
			e.printStackTrace();
		}
		try {
			out.println("<tr><th>Temp_max     :  </th><th>" + main.get("temp_max")+"</th></tr>");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			out.println("<tr><th>Temp_max   :  </th><th>not found</th></tr>");
			e.printStackTrace();
		}
		try {
			out.println("<tr><th>Temp_min     :  </th><th>" + main.get("temp_min")+"</th></tr>");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			out.println("<tr><th>Temp_min   :  </th><th>not found</th></tr>");
			e.printStackTrace();
		}
		
		try {
			out.println("<tr><th>Pressure     :  </th><th>" + main.get("pressure")+"</th></tr>");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			out.println("<tr><th>Pressure   :  </th><th>not found</th></tr>");
			e.printStackTrace();
		}
		try {
			out.println("<tr><th>Humidity     :  </th><th>" + main.get("humidity")+"</th></tr>");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			out.println("<tr><th>Humidity   :  </th><th>not found</th></tr>");
			e.printStackTrace();
		}
		finally {
			
		}
		out.print("</table>");
		out.print("<br>");
		out.print(" <form action=\"LocationServlet\">" + 
				  "<input type=\"text\" name=\"fname\" required>" +
				  " 	<input type=\"submit\" value=\"Change city\">" + 
				  " </form>");
	}

}
